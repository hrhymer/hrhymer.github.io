<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>72 CAST for V-COMMERCE</title>
		<meta name="description" content="We will change worldwide e-commerce THE INNOVATION TO MOBILE V-COMMERCE.">
		<meta name="keywords" content="video, live, commerce, mobile, chat">
		<meta name="naver-site-verification" content="d60a4039cc1698ce7491a43b0967146ad6dd72eb"/>
		<script src="dist/js/jquery-1.12.0.min.js"></script>	
		<script src="dist/js/tether.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!--script src="dist/js/bootstrap.min.js"></script-->
		<script src="https://cdn.jsdelivr.net/jquery.leanmodal2/2.3/jQuery.leanModal2.min.js"></script>
		<script src="http://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
		<script src="http://vjs.zencdn.net/5.10.2/video.js"></script>
		<script src="assets/js/main.js"></script>
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
		<link href="http://vjs.zencdn.net/5.10.2/video-js.css" rel="stylesheet">
		<!--link rel='stylesheet' href='dist/css/bootstrap.min.css' /-->
		<!--link rel='stylesheet' href='dist/css/bootstrap-theme.css' /-->	
		<link rel='stylesheet' href='assets/css/style.css' />

		<!-- ������Ʈ �ε��� ������ �� -->
		<link rel='stylesheet' href='assets/css/animate.css' />
		
		<!-- ������ ��� Ȯ�� ���� -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!--��Ʈ -->
		<link href='https://fonts.googleapis.com/css?family=Maven+Pro:400,500,700,900' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,300italic' rel='stylesheet' type='text/css'>
		

		<!-- ���� �����̴� �� -->
		<!--link rel="stylesheet" type="text/css" href="assets/js/slick/slick.css"/>
		<link rel="stylesheet" type="text/css" href="assets/js/slick/slick-theme.css"/-->

		<meta name="naver-site-verification" content="240e7a17fa95ca1cf35b7267916a9942bb00cf91"/>
	</head>
	<body><meta name="format-detection" content="telephone=no">
<body style="margin: 0;">
<div class="m_container">

<!--       -->
<!--       -->
<!-- maincontainer -->
<!--       -->
<!--       -->


	<div class="m_deck01" style="text-align: center;">
		<div class="top_menu">
			<div style="float: left;"><a href="/"><img src="assets/img/logo.png" alt="72 CAST" /></a></div>
			<div style="float: right;">

				<div class="top_language" style=""><span style="color: #fff">KO</span></a> / <a href="/index.php"><span style="color: #80a0cc">EN</span> / <a href="/index-cn.php"><span style="color: #80a0cc">CN</span></a></div>
				<div style="float: left; display: none;"><img src="assets/img/btn03.png" alt="Menu" /></div>
			</div>			

		</div>
		<div class="top_slider">
		<div class="left_image"><img src="assets/img/mobile01.png" alt="" /></div>
		<div class="right_part">
			<h1 class="right_part01">We build a video commerce platform for you</h1>
			<div class="right_part02">THE INNOVATION TO</div>
			<div class="right_part03">MOBILE <span class="maven">V-COMMERCE</span></div>
			<div class="right_part04">
				<div class="app_btn"><a href="http://demo.72cast.com/admin" target="_blank"><img src="assets/img/demo_btn2.png" alt="LAUNCH DEMO" /></a></div>
			</div>
			<div class="right_part05">
				라이브 동영상을 이용한 모바일 비디오 커머스 시스템 및 그 방법<br>특허 출원 번호(한국) 10-2016-0037303<br/><br/>
			<a href="https://itunes.apple.com/app/id1050483625" target="_blank"><img src="assets/img/appstore.png" alt="Download on the App Store" /></a>
			<a href="https://play.google.com/store/apps/details?id=com.applr.baubox.shop" target="_blank"><img src="assets/img/googleplay.png" alt="Get it on Google play" /></a>
			</div>
		</div>
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- MOBILE V-COMMERCE PLATFORM -->
<!--       -->
<!--       -->

<div class="deck2">
	<div class="section01"><img src="assets/img/p_img_02.jpg" alt="" /></div>
	<div class="section02">
		<h2 class="section02_1">MOBILE V-COMMERCE PLATFORM</h2>
		<div class="section02_3">72CAST는  72초 길이의 라이브  비디오 콘텐츠 방송을 통해 소비자에게  제품을 더욱 자세히 이해시키고  구매를 촉진 시키는  혁신적인 모바일 비디오 커머스 플랫폼입니다 
		</div>

		<div class="section02_4">72CAST는 혁신적인 라이브 비디오 스트리밍 기술과 실시간 채팅 기능을 제공하여 판매자와 그들의 고객을 더 가깝게 연결시키고 새로운 활력을 찾는 당신의 비즈니스 모델에 최적의 솔루션을 제공합니다.
		</div>


		<!--div class="section02_1">MOBILE V-COMMERCE</div>
		<div class="section02_2">PLATFORM</div>
		<div class="section02_3">72CAST는 “72초”라는 짧은 제품소개 영상을 기반으로 “판매자라면 누구나가 ‘72초’짜리 실시간 세일즈 방송을 할 수 있는 플랫폼”이다.
		</div>
		<div class="section02_4">짧막한 비디오를 즐겨 보는 요즘 젊은 세대를 겨냥한 커머스 관련 영상을 제공해 기존의 이미지 기반의 커머스 서비스 보다 높은 구매력을 만들 수 있는 새로운 패러다임을 만드는 “비디오 기반의 커머스 플랫폼 서비스” 회사이다.
		</div-->

	</div>

</div>

<!--       -->
<!--       -->
<!-- WHY VIDEO COMMERCE? -->
<!--       -->
<!--       -->

<div class="deck3">
	<h2 class="deck3_title">WHY VIDEO COMMERCE?</h2>
	<div class="deck3_subtitle">Direct relationship between Video and Commerce</div>
	<div class="container">
		<ul class="why_list clearfix">
			<li>
				<h3>250%</h3>
				<p>이메일 CRT 250% 상승</p>
			</li>
			<li>
				<h3>75%</h3>
				<p>75%의 사용자가 동영상 시청 후 웹사이트 방문</p>
			</li>
			<li>
				<h3>74%</h3>
				<p>제품이나 서비스에 대한 시청자의 이해도 74% 상승</p>
			</li>
			<li>
				<h3>85%</h3>
				<p>85%의 소비자들이 동영상 시청 후 상품 구매 의욕 상승</p>
			</li>
			<li>
				<h3>2 minutes</h3>
				<p>동영상 시청한 고객들이 다른 고객에 비해 평균 2분 이상 웹사이트 체류</p>
			</li>
		</ul>
	</div>
</div>

<!--       -->
<!--       -->
<!-- MOBILE COMMERCE APP -->
<!--       -->
<!--       -->

<!--
<div class="deck5 mcapp">
	<h2 class="deck5_title">MOBILE COMMERCE APP</h2>
	<div class="clearfix">
		<div class="mcapp_text">
<<<<<<< .merge_file_a02784
			72CAST provides real-time chat features and advanced live video streaming service. With these features, anyone could broadcast live video and interact with the viewers. You may also run the effective digital marketing campaign with our simulcast technology uploading the video contents automatically to SNS.
=======
			72CAST의 초기 화면으로 각 로컬의 개성있고 인디적인 브랜드를 발굴하고 참여시켜 고객들이 선호하는 브랜드를 팔로우 하거나 좋아하는 브랜드의 제품을 모아보고 직접 구매까지 할 수 있는 앱의 모습입니다.
			브랜드의 다양한 상품을 경험하기 위해 상품의 품질을 최대한 보호하고 높은 퀄리티의 사진을 제공하고 있습니다.
			직관적인 UX는 “모바일 커머스”의 사용자의 경험을 극대화하고 있도록 설계 되었습니다.
>>>>>>> .merge_file_a09160
		</div>
		<div class="deck3_1_img"><img src="assets/img/commerce_app1.png" alt="" /></div>
	</div>
</div>
<div class="deck5 mcapp2">
	<div class="deck3_1_img"><img src="assets/img/commerce_app2.png" alt="" /></div>
	<div  class="mcapp_text">
<<<<<<< .merge_file_a02784
		<div>Our global logistic network promises easy and simple delivery system and big data based sophisticated recommend algorithm grants unparalleled personalized customer service. On the other hand the sellers will experience our advanced ecommerce back-end engine to manage the entire online process with one screen.</div>
	</div>
=======
		<div>72CAST의 장바구니의 결제는 매번 구매반복이 가능한 상품(샴푸, 음식 등의 소비제 상품)에 대해서는 반복배송을 신청할 수 있는 기능을 제공합니다.
			<br><br>
			따라서 매번 구매를 하지 않아도 반복배송을 걸어놓으면 지속적인 결제와 배송이 가능하고 또한 언제든지 취소도 가능합니다.</div>
		</div>
>>>>>>> .merge_file_a09160
</div>
-->

<!--       -->
<!--       -->
<!-- THE 3 MAJOR FACTORS V-COMMERCE -->
<!--       -->
<!--       -->

<div class="deck4 bluebg">
<h2 class="deck4_title">THE 3 MAJOR FACTORS OF V-COMMERCE</h2>
	<div class="deck4_cont">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/cont4_01.png" alt="" width="120px" height="120px" />
			</div>
			<!--div class="deck4_cont01_2">
				Vendor's Broadcast
			</div-->
			<div class="deck4_cont01_3">
				Live<br> Streaming
			</div>
			<!--div class="deck4_cont01_4">
				It is a new concept for e-commerce, which combines 
				marketplace and MCN.
				Our innovative mobile v-commerce platform allows vendors to broadcast their product 
				like the TV home shopping channel and to communicate with customers on real time basis.
			</div-->
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/cont4_02.png" alt="" width="120px" height="120px" />
			</div>
			<!--div class="deck4_cont01_2">
				Flexible&Expandable
			</div-->
			<div class="deck4_cont01_3">
				Mobile Commerce<br> Platform
			</div>
			<!--div class="deck4_cont01_4">
				Our platform provides 
				user-friendly UI and one-stop console management with 
				900 payment gateways, 300-language pack and 400 shipping method so that 
				each vendor easily controls 
				the entire business process 
				with just one click.
			</div-->
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/cont4_03.png" alt="" width="120px" height="120px" />
			</div>
			<!--div class="deck4_cont01_2">
				Recommend Algorithm
			</div-->
			<div class="deck4_cont01_3">
				Personalized<br>
				Big Data Analysis
			</div>
			<!--div class="deck4_cont01_4">
				We are specializing in Big Data analysis so our platform offers customers an unparalleled shopping experience with personalized display, 
				item recommendation and preferable brand suggestion. Our sophisticated recommend algorithm will find out customers' need before they find it.
			</div-->
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- SELF-BROADCASTING OF THE VENDOR -->
<!--       -->
<!--       -->

<div class="deck5">

	<h2 class="deck5_title">SELF-BROADCASTING<br>FUNCTION FOR VENDORS</h2>
	<div class="deck5_subtitle">누구나 간단한 로그인 후 ‘라이브’ 버튼 클릭 한번으로 누구나 라이브 비디오 컨텐츠를 방송할수 있습니다.  벤더의 경우 영상이 서버와 접속되어 팔고자 하는 상품을 선택할수 있고 방송중 실시간 방문자 및 매출 현황을 체크할수 있습니다.  방송후에도 동영상은 자동으로 녹화되어 다시 시청이 가능합니다.

	</div>

	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone05_1_1.png" alt="Vendor's Special Broadcasting Menu" />
<!-- 				<div class="player">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/vendor1_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">

				&lt;벤더만의 방송 메뉴&gt;
			</div>

		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone05_2_1.png" alt="Live Broadcasting of Server Connect" class="hidden-xs" />
				<img src="assets/img/phone05_2_1_m.png" alt="Live Broadcasting of Server Connect" class="visible-xs" />
<!-- 				<div class="player" style="top:72px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/vendor2_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">

				&lt;서버와 연결된 라이브 방송&gt;

			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone05_3_1.png" alt="Vendor's Live Channel Looks" />
<!-- 				<div class="player">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/vendor3_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">

				&lt;벤더의 실제 방송 채널 모습&gt;
			</div>

		</div>
	</div>
</div>
<div class="deck5_1">


	<h2 class="deck5_title">JOIN THE LIVE BROADCAST <br> AS A CUSTOMER</h2>
	<div class="deck5_subtitle">일반 유저들에게 카테고리별 동영상이 제공됩니다. 방송시청중 시청자는 직접 실시간 메세지를 보내 판매자와 소통하며 자신의 궁금증들을 해소할수 있습니다.	

	</div>

	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">				
				<img src="assets/img/phone06_1_1.png" alt="Customer's Live Channel Looks" />
<!-- 				<div class="player" style="top:72px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/user1_720p.mov" type='video/mp4'>
					</video>
				</div> -->				
			</div>
			<div class="deck5_cont01_2">

				&lt;소비자의 방송 채널 화면&gt;
			</div>

		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone06_2_1.png" alt="Live Broadcasting & interaction" />
<!-- 				<div class="player" style="top:71px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/user2_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">

				&lt;라이브 방송과 벤더와의 인터렉션&gt;
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone06_3_1.png" alt="Customer's Product Detail" />
<!-- 				<div class="player" style="top:71px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/user3_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">

				&lt;소비자를 위한 상세상품 설명&gt;
			</div>

		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- Simulcast -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title">SIMULCAST</h2>
	<div class="deck5_subtitle nthem">
		컨텐츠 제작시 시뮬캐스트 기능을 통해 동영상을 사용자가 원하는 소셜계정에 올릴수가 있습니다. 예를 들면 방송을 하기전에 이 시뮬케스트기능을 선택하면 앱에서 최적의 서버를 찾아서 자동으로 연결을 하고 페이스북, 유투부나 인스타그램 같은 SNS에 자동으로 업로딩을 해줍니다.
	</div>
	
	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/simulcast1.png" alt="Screenshot1" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/simulcast2.png" alt="Screenshot2" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/simulcast3.png" alt="Screenshot3" />
			</div>
		</div>
	</div>
	
</div>

<!--       -->
<!--       -->
<!-- ADMINISTRATOR CONSOLE -->
<!--       -->
<!--       -->

<div class="deck6 blackbg">
	<h2 class="deck6_title">ADMINISTRATOR CONSOLE</h2>
	<div class="deck6_subtitle">EC 엔진의 백엔드 시스템은 글로벌화에 초점을 맞추었으며, 전세계의 PG 900개, 언어 300개, 물류배송 모듈 400개를 확보하고 있어 굉장한 확장성과 유연성을 갖고 있습니다. 이제 벤더들은 중요한 업무를 관리자페이지에서 원스톱으로 판매업무에 집중할 수 있습니다.
	</div>
	<div class="deck6_cont">
		<img src="assets/img/img_exp02.png" alt="Admin Panel" />
	</div>
	<div class="deck4_cont">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/language.png" alt="language" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3 sizeup">
				<strong>300</strong> Languages
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/payment.png" alt="payment" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3 sizeup">
				<strong>900</strong> Payment Gateways
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/shipping.png" alt="shipping" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3 sizeup">
				<strong>400</strong> Shipping
			</div>
		</div>
	</div>

</div>

<!--       -->
<!--       -->
<!-- 72 CAST SERVICE GRADE -->
<!--       -->
<!--       -->

<div class="deck7">
	<h2 class="deck5_title"><span class="logo_72">72</span> <span class="logo_cast">CAST</span> B2B SERVICE GRADE</h2>
	

	<div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title01 price_table_title">Basic<br/><span>(Small Biz Type)</span></div>
        <div><div class="price_table_price">-/-</div>
			<div class="price_table_term">List Month / Per month</div></div>
        <div class="price_table_text"> White Level </div>
		<div class="price_table_text">-</div>
        <div class="price_table_text">B EC Engine</div>
        <div class="price_table_text">Standalone</div>
        <div class="price_table_text">Server fee include</div>
		<div class="price_table_text">Basic API</div>
		<div class="price_table_text">SNS Basic Connection</div>
        <div class="price_table_text">-</div>
        <div class="price_table_text">Platform Payment</div>
        <div class="price_table_text">fee 5%</div>
        <div class="price_table_text">B EC 2 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">Price / Maintenance(monthly)</div>
    </div>
    <div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title02 price_table_title">Standard<br/><span>(Medium Biz Type)</span></div>
        <div><div class="price_table_price">-/-</div>
			<div class="price_table_term">List Month / Per month</div></div>
		<div class="price_table_text"> White Level </div>
        <div class="price_table_text"> - </div>
        <div class="price_table_text">S EC Engine</div>
        <div class="price_table_text">Medium Market</div>
		<div class="price_table_text">Server fee include</div>
		<div class="price_table_text">Basic API</div>
		<div class="price_table_text">SNS Basic Connection</div>
		<div class="price_table_text">Push Alarm 5,000</div>
		<div class="price_table_text">Platform Payment</div>
        <div class="price_table_text">fee 10%</div>
        <div class="price_table_text">S EC 2 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">Price / Maintenance(monthly)</div>
    </div>
    <div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title03 price_table_title">Premium<br/><span>(Enterprise Biz Type)</span></div>
        <div><div class="price_table_price">-/-</div>
        	 <div class="price_table_term">List Month / Per month</div></div>
        <div class="price_table_text"> White Level </div>
		<div class="price_table_text"> V-Commerce (72sec) </div>
        <div class="price_table_text">P EC Engine</div>
        <div class="price_table_text">Open Market</div>
		<div class="price_table_text">Server fee not included</div>
		<div class="price_table_text">Extention API</div>
		<div class="price_table_text">SNS Simulcast</div>
		<div class="price_table_text">Push Alarm 500,000</div>
		<div class="price_table_text">Independent Payment</div>
        <div class="price_table_text">fee 15%</div>
        <div class="price_table_text">P EC 2 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">Price / Maintenance(monthly)</div>
    </div>
    <div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title04 price_table_title">Professional<br/><span>(Enterprise Biz Type)</span></div>
        <div><div class="price_table_price">-/-</div>
        	 <div class="price_table_term">List Month / Per month</div></div>
<div class="price_table_text"> - </div>
	   <div class="price_table_text"> V-Commerce (unlimited) </div>
        <div class="price_table_text">Pro EC Engine + Custom</div>
        <div class="price_table_text">Open Market</div>
		<div class="price_table_text">Server fee not included</div>
		<div class="price_table_text">Extention API + Existing Sys Integration</div>
		<div class="price_table_text">SNS Simulcast</div>
		<div class="price_table_text">Push Alarm 1,000,000</div>
		<div class="price_table_text">Independent Payment</div>
        <div class="price_table_text">-</div>
        <div class="price_table_text">P EC 3 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">Price / Maintenance(monthly)</div>
    </div>
	<!--div class="btn_free_wrap">
		<a href="javascript:void(0);">Free Trial</a>
	</div-->

	<div id="contact">
		<form name='sendmail' role='form' method='post' action=>
			<div class="sendmail clearfix">
				<ul class="clearfix">
					<li><input tyle="text" placeholder="First *" name="first_name"/></li>
					<li><input tyle="text" placeholder="Last *" name="last_name"/></li>
					<li><input tyle="text" placeholder="E-mail *" name="email"/></li>
					<li><input tyle="text" placeholder="Company name *" name="company_name"/></li>
					<li><input tyle="text" placeholder="Phone *" name="telephone"/></li>
					<li><input tyle="text" placeholder="URL" name="url"/></li>
					<li class="double"><textarea col="50" row="10" placeholder="Comment" name="comments"></textarea></li>
				</ul>
				<!--<div id="RecaptchaField1"></div>-->
				<input type='submit' name='submit' value='SEND'/>
				<input type='button' class='close' value='CLOSE'/>

			</div>
		</form>
	</div>
	<script>$('.price_table').leanModal({top:0, closeButton: '.close'});</script>
</div>

<!--       -->
<!--       -->

<div class="deck9">
	<div class="deck5_title">MCN INFLUENCERS</div>
	<div class="deck5_subtitle">비디오 커머스 리더인 72CAST와 함께 이커머스 트렌드를 바꾸실 참신하고 열정적인 소셜 인플루언스를 모집합니다. 재미있고 손쉽게 유명 소셜인플루엔서가 되고 싶으신 분은 연락 주시기 바랍니다.</div>
<div class="deck9_inside">

<div class="noplay">
          <div class="span3">
          	<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ1.png" width="180px" height="180px"></div>
          		<div class="mem_name">Cho Long Kwon</div>
          		
          	</div>
          </div>
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ2.png" width="180px" height="180px"></div>
          		<div class="mem_name">Hyun Young Yoon</div>
          		
          	</div>
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ3.png" width="180px" height="180px"></div>
          		<div class="mem_name">Somevely</div>
          		
          	</div>
          </div>         
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ4.png" width="180px" height="180px"></div>
          		<div class="mem_name">Su Il Kim</div>
          		
          	</div>
          </div>

          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ5.png" width="180px" height="180px"></div>
          		<div class="mem_name">So Hyun Lee</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ6.png" width="180px" height="180px"></div>
          		<div class="mem_name">Hee Kyung Jeon</div>
          		
          	</div>	
          </div>
           <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ7.png" width="180px" height="180px"></div>
          		<div class="mem_name">Milkiss</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ8.png" width="180px" height="180px"></div>
          		<div class="mem_name">Min Ji Bae</div>
          		
          	</div>	
          </div>

      </div>
      <a href="mailto:contact@72cast.com"><input type='button' name='JOIN' value='J O I N'/></a>
  </div>
<!--
<div class="autoplay">
          <div class="span3">
          	<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ1.png"></div>
          		<div class="mem_name">Daniel D.J UM</div>
          		
          	</div>
          </div>
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ2.png"></div>
          		<div class="mem_name">Josephina S.Y Lee</div>
          		
          	</div>
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ3.png"></div>
          		<div class="mem_name">Thomas H.W Kang</div>
          		
          	</div>
          </div>         
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ4.png"></div>
          		<div class="mem_name">Justin M.K Kim</div>
          		
          	</div>
          </div>
          
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ5.png"></div>
          		<div class="mem_name">Duke J.W Mok</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ6.png"></div>
          		<div class="mem_name">Chris M.D Yeo</div>
          		
          </div>
          </div>
           <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ7.png"></div>
          		<div class="mem_name">Duke J.W Mok</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ8.png"></div>
          		<div class="mem_name">Chris M.D Yeo</div>
          		
          	</div>	
          </div>
  </div>-->

<script type="text/javascript" src="assets/js/slick/slick.min.js"></script>

</div>  
  
</div>

<!--       -->
<!--       -->
<!-- 72 CAST of extension industry -->
<!--       -->
<!--       -->

<div class="deck3 bluebg">
	<h2 class="deck3_title">EXTENSION INTDUSTRY</h2>
	

	<div class="deck4_cont">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/game.png" alt="" width="120px" height="120px"/>
			</div>
			<div class="deck4_cont01_3">
				Online Games Industry
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/art.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				Live Art Auction
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/eTicketing.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				e-Ticketing
			</div>
		</div>
	</div>
	<div class="deck4_cont second">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/travel.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				Travel &amp; Leisure
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/luxury_brand.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				Luxury Brand
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/fashion.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				Fashion &amp; Cosmetic
			</div>
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- Portfolio of 72 CAST -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title">PORTFOLIO</h2>
	<ul class="portfolio clearfix">
		<li class="Line"><img src="assets/img/logo1.png" alt="Line" /></li>
		<li><img src="assets/img/logo2.png" alt="Deutsch Telekom" /></li>
		<li class="CheetahMobile"><img src="assets/img/logo3.png" alt="Cheetah Mobile" /></li>
		<li><img src="assets/img/logo4.png" alt="FarEasTone" /></li>
		<li class="SCSB"><img src="assets/img/logo5.png" alt="SCSB" /></li>
		<li><img src="assets/img/logo6.png" alt="Mediacorp" /></li>
		<li class="Benz"><img src="assets/img/logo7.png" alt="Benz" /></li>
		<li><img src="assets/img/logo8.png" alt="Amadeus" /></li>
		<li class="Mediacom"><img src="assets/img/logo9.png" alt="Mediacom" /></li>
		<li class="more hidden-sm hidden-xs"><img src="assets/img/logo_more.png" alt="More" /></li>
	</ul>
	
</div>

<!--       -->
<!--       -->
<!-- 525 CAST (O2O Model) -->
<!--       -->
<!--    
<div class="deck5">
	<h2 class="deck5_title">525 CAST</h2>
	<div class="o2o clearfix">
		<div class="deck3_1_img"><img src="assets/img/o2o_model.png" alt="" /></div>
		<div class="o2o_text">
			<h3>Features of 525 Cast (O2O Model)</h3>
			1) Service for easy communication with off-line shop clerk<br/><br/>
			2) Direct P2P video calling and chat (No Server)<br/><br/>
			3) Web RTC video call for up to 12 people at once<br/><br/>
			4) CRM with 1:1 video calls and O2O-based video call orders<br/><br/>
			5) An effective tool for VIP and special customer management<br/><br/>
			6) Can be synchronised with in-store POS systems and/or iPads
		</div>
	</div>
</div>

    -->
<!--       -->
<!-- GLOBAL LOGISTIC NETWORK -->
<!--       -->
<!--       -->

<div class="deck8">

	<!-- Global Logistic network... -->
	<div class="m_container" style="text-align:center; background-color:#3b3d40;">
		<div class="global">
			<div style="">				
				<h2 class="global_title">GLOBAL LOGISTICS NETWORK</h2>
				<br><br/>
				<div class="global_text">72CAST는 글로벌한 커머스 플랫폼을 위한 지향점을 가지고 있습니다. ICT기술만 준비되어 있는 것이 아니라 물류서비스도 글로벌하게 제공이 가능합니다.
우리는 현재 홍콩의 글로벌 로지스틱 업체와 협력이 되어 있는 상태며,
17개국 42개의 브랜치를 활용한 글로벌 물류배송이 가능합니다.</div>
				<br>
				<div class="global_text">이러한 물류 브랜치를 활용한 글로벌 물류배송이 가능합니다.
이러한 물류 브랜치는 향후 앱의 1차 런칭 국가이며 그외의 국가별 진출에 따라 지속적으로 늘려 나갈 예정입니다.</div>
			</div>
		</div>
	</div>
	<div class="container logistic">        
		<ul class="clearfix">
			<li><img src="assets/img/logo_korchina.png" alt="KORCHINA" /></li>
			<li><img src="assets/img/logo_ocs.png" alt="OCS" /></li>
			<li><img src="assets/img/logo_yamato.png" alt="YAMATO" /></li>
			<li><img src="assets/img/logo_freeway.png" alt="FREE WAY" /></li>
		</ul>
	</div>

</div>

<!--       -->
<!--       -->
<!-- Portfolio of 72 CAST -->
<!--       -->
<!--       -->

<!--<div class="deck5">
	<h2 class="deck5_title">Portfolio</h2>
	<ul class="portfolio clearfix">
		<li class="Line"><img src="assets/img/logo1.png" alt="Line" /></li>
		<li><img src="assets/img/logo2.png" alt="Deutsch Telekom" /></li>
		<li class="CheetahMobile"><img src="assets/img/logo3.png" alt="Cheetah Mobile" /></li>
		<li><img src="assets/img/logo4.png" alt="FarEasTone" /></li>
		<li class="SCSB"><img src="assets/img/logo5.png" alt="SCSB" /></li>
		<li><img src="assets/img/logo6.png" alt="Mediacorp" /></li>
		<li class="Benz"><img src="assets/img/logo7.png" alt="Benz" /></li>
		<li><img src="assets/img/logo8.png" alt="Amadeus" /></li>
		<li class="Mediacom"><img src="assets/img/logo9.png" alt="Mediacom" /></li>
		<li><img src="assets/img/logo_more.png" alt="More" /></li>
	</ul>

</div>-->

<!--       -->
<!--       -->
<!-- CONCEPT PRODUCT<br/>WITH &THEM -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title"><span class="logo_72">72</span> <span class="logo_cast">CAST</span> USING THE OUR<br> FIRST PROJECT:<!--span class="logo_nthem">&amp;THEM</span--><span class="logo_nthem2"><img src="assets/img/logo_blue.png" alt="&THEM" width="200px" /></span></h2>
	<div class="nthem_container">
	<div class="deck5_subtitle nthem">
		&amp;THEM에서 추구하는 상품의 컨셉은 18세 ~ 35세의 젋은 계층이 선호하는 젊고, 인디적이며 실험성이 뛰어난 상품으로 이를 비디오 컨텐츠와 함께 라이프스타일에 맞추어 고객에게 다가가고 있으며, 현재 루이스클럽을 비롯해 다양한 분야에서의 개성있는 여러 디자인 브랜드가 참여하고 있습니다.

	</div>

	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/nthem01.png" alt="Screenshot1" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/nthem02.png" alt="Screenshot2" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/nthem03.png" alt="Screenshot3" />
			</div>
		</div>
	</div>

	<div class="market">
		<em>Enjoy the v-commerce shopping experience.</em>
		<div class="go_market">
			<a href="https://itunes.apple.com/app/id1095994523" target="_blank"><img src="assets/img/banner1.png" alt="Download on the App Store" /></a>
			<a href="https://play.google.com/store/apps/details?id=com.applr.nthem.shop" target="_blank"><img src="assets/img/banner2.png" alt="Get it on Google play" /></a>
		</div>
	</div>
	</div>
</div>

<!--        -->
<!--        -->
<!-- We will change worldwide e-commerce -->
<!--        -->
<!--        -->

<div class="deck10">
	<div class="m_container" style="text-align:center; background-image:url('assets/img/back_b_b.png'); background-position: center; " >
		<div class="bb_big_top">
			<div class="bb_big">
				<span class="bb_big_title">We</span><br>
				<span class="bb_big_title">will ch</span><span class="bb_big_title2">ange</span><br>
				<span class="bb_big_title">world</span><span class="bb_big_title2">wide</span><br>
				<span class="bb_big_title">e</span><span class="bb_big_title2">-commerce</span>
			</div>
		</div>
		<div class="bb_big_top2">
			<div class="bb_big2">
				<div class="bb_big_image"><img src="assets/img/we_sl.png" alt="" /></div>
			</div>
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- Start free trial of 72 CAST -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title">CONTACT US<!-- OF<br/><span class="logo_72">72</span> <span class="logo_cast">CAST</span--></h2>
	<div class="contact_subtitle">
		저희 데모를 써보시고 좀더 귀하의 비즈니스에 모델에 알맞은 서비스를 제공하기 위해 연락가능한 메일 주소나 번호를 남겨주시기 바랍니다.
	</div>
	<form name='sendmail' role='form' method='post' action=>
		<div class="sendmail clearfix">
			<ul class="clearfix">
				<li><input tyle="text" placeholder="First *" name="first_name"/></li>				
				<li><input tyle="text" placeholder="Last *" name="last_name"/></li>
				<li><input tyle="text" placeholder="E-mail *" name="e-mail"/></li>
				<li><input tyle="text" placeholder="Company name *" name="company_name"/></li>
				<li><input tyle="text" placeholder="Phone *" name="telephone"/></li>
				<li><input tyle="text" placeholder="URL" name="url"/></li>
				<li class="double"><textarea col="50" row="10" placeholder="Comment" name="comments"></textarea></li>
			</ul>
			<!--<div id="RecaptchaField2"></div>-->
			<input type='submit' name='submit' value='S E N D'/>
		</div>
	</form>
</div>

<!--        -->
<!--        -->
<!-- Address -->
<!--        -->
<!--        -->

<div class="deck3">
	<div class="m_deck_rest" >
		<div class="mbottom_logo">
			<!--img src="assets/img/bottom_logo_72cast.png"-->
			<img src="assets/img/72cast_logo.png" alt="72 CAST" />
		</div>
		<div class="mbottom_text03">
			<a href="mailto:contact@nthemshop.com.sg" style="color: white">contact@72cast.com</a>
		</div>
		<div class="mbottom_text04">
			Korea Office :  대한민국 서울시 강서구 공항대로59다길 33, 07553<br/>
			Singapore Office : 71 Ayer Rajah Crescent #05-05 Singapore 139951<br/>
		</div>


		<!--<div class="mbottom_icon2">
			<img src="assets/img/sns1.png" alt="facebook" />
			<img src="assets/img/sns2.png" alt="twitter" />
			<img src="assets/img/sns3.png" alt="instagram" />
		</div>-->
	</div>
</div>

<script>

$(".price_table").hover(function(e){
	$(this).children("div:first").addClass('price_table_title_over');
	$(this).children("div:last").addClass('price_table_title_over');
},function(e){
	$(this).children("div:first").removeClass('price_table_title_over');
	$(this).children("div:last").removeClass('price_table_title_over');
});

</script>

<!-- google analytics -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79445648-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript">
  var onloadCallback = function() {    
    grecaptcha.render('RecaptchaField1', 
    	{
    		'sitekey' : '6LezNScTAAAAAOVNd0nmClPkryScSuCD9V3AC4Yu'
    	});
    grecaptcha.render('RecaptchaField2', 
    	{
    		'sitekey' : '6LezNScTAAAAAOVNd0nmClPkryScSuCD9V3AC4Yu'
    		// 'theme' : 'dark'
    	});
  };
</script>