<!DOCTYPE html>
<html lang="en">
	<head>
		<title>72 CAST for V-COMMERCE</title>
		<meta name="description" content="We will change worldwide e-commerce THE INNOVATION TO MOBILE V-COMMERCE.">
		<meta name="keywords" content="video, live, commerce, mobile, chat">
		<meta name="naver-site-verification" content="d60a4039cc1698ce7491a43b0967146ad6dd72eb"/>
		<script src="dist/js/jquery-1.12.0.min.js"></script>	
		<script src="dist/js/tether.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!--script src="dist/js/bootstrap.min.js"></script-->
		<script src="https://cdn.jsdelivr.net/jquery.leanmodal2/2.3/jQuery.leanModal2.min.js"></script>
		<script src="http://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
		<script src="http://vjs.zencdn.net/5.10.2/video.js"></script>
		<script src="assets/js/main.js"></script>
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
		<link href="http://vjs.zencdn.net/5.10.2/video-js.css" rel="stylesheet">
		<!--link rel='stylesheet' href='dist/css/bootstrap.min.css' /-->
		<!--link rel='stylesheet' href='dist/css/bootstrap-theme.css' /-->	
		<link rel='stylesheet' href='assets/css/style.css' />

		<!-- ������Ʈ �ε��� ������ �� -->
		<link rel='stylesheet' href='assets/css/animate.css' />
		
		<!-- ������ ��� Ȯ�� ���� -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!--��Ʈ -->
		<link href='https://fonts.googleapis.com/css?family=Maven+Pro:400,500,700,900' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,300italic' rel='stylesheet' type='text/css'>
		

		<!-- ���� �����̴� �� -->
		<!--link rel="stylesheet" type="text/css" href="assets/js/slick/slick.css"/>
		<link rel="stylesheet" type="text/css" href="assets/js/slick/slick-theme.css"/-->

		<meta name="naver-site-verification" content="240e7a17fa95ca1cf35b7267916a9942bb00cf91"/>
	</head>
	<body><meta name="format-detection" content="telephone=no">
<body style="margin: 0;">
<div class="m_container">

<!--       -->
<!--       -->
<!-- maincontainer -->
<!--       -->
<!--       -->


	<div class="m_deck01" style="text-align: center;">
		<div class="top_menu">
			<div style="float: left;"><a href="/"><img src="assets/img/logo.png" alt="72 CAST" /></a></div>
			<div style="float: right;">
				<div class="top_language" style=""><a href="/index-ko.php"><span style="color: #80a0cc">KO</span></a> / <a href="/index.php"><span style="color: #80a0cc">EN</span> / <span style="color: #fff">CN</span></a></div>
				<div style="float: left; display: none;"><img src="assets/img/btn03.png" alt="Menu" /></div>
			</div>			
		</div>
		<div class="top_slider">
		<div class="left_image"><img src="assets/img/mobile01.png" alt="" /></div>
		<div class="right_part">
			<h1 class="right_part01">We build a video commerce platform for you</h1>
			<div class="right_part02">带给您一个创新的行动视</div>
			<div class="right_part03">频电子商务的服务平台</span></div>
			<div class="right_part04">
				<div class="app_btn"><a href="http://demo.72cast.com/admin" target="_blank"><img src="assets/img/demo_btn2.png" alt="LAUNCH DEMO" /></a></div>
			</div>
			<div class="right_part05">
				一个提供现场视频直播及现场沟通的行动视频电子商务的服务平台<br>专利号 (韩国) 10-2016-0037303<br/><br/>
			<a href="https://itunes.apple.com/app/id1050483625" target="_blank"><img src="assets/img/appstore.png" alt="Download on the App Store" /></a>
			<a href="https://play.google.com/store/apps/details?id=com.applr.baubox.shop" target="_blank"><img src="assets/img/googleplay.png" alt="Get it on Google play" /></a>
			</div>
		</div>
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- MOBILE V-COMMERCE PLATFORM -->
<!--       -->
<!--       -->

<div class="deck2">
	<div class="section01"><img src="assets/img/p_img_02.jpg" alt="" /></div>
	<div class="section02">
		<h2 class="section02_1">行动视频电子商务的服务平台</h2>
		<div class="section02_3">72CAST是一个崭新的移动可视电子商务平台，我们也将其定位为电子商务平台的次世代继承者。在我们的平台上，销售者可以上传长达72秒的短片来把他们的产品介绍给一般用户而且导引购买。
		</div>
		<div class="section02_4">这视频电商平台及附属的即时沟通（Live Chat）功能可以更加紧密地将销售与客户联系起来。如果您在寻找往前飞跃的一步，不妨尝试一下我们的平台。我们将帮助您在业务运营的提高、品牌形象的优化方面取得突破。
		</div>
	</div>
	
</div>

<!--       -->
<!--       -->
<!-- WHY VIDEO COMMERCE? -->
<!--       -->
<!--       -->

<div class="deck3">
	<h2 class="deck3_title">我们为什么选择开发视频电子商务呢？</h2>
	<div class="deck3_subtitle">视频与商务之间的直接关系</div>
	<div class="container">
		<ul class="why_list clearfix">
			<li>
				<h3>250%</h3>
				<p>电邮点击率增加到250%</p>
			</li>
			<li>
				<h3>75%</h3>
				<p>75% 的用户看了某一家网站的视频后而实际上点击进去网站</p>
			</li>
			<li>
				<h3>74%</h3>
				<p>74%的用户觉得视频有助于提高他们对某一个产品或服务的认知度</p>
			</li>
			<li>
				<h3>85%</h3>
				<p>85% 的用户在看了视频以后更有可能实际购买某一个产品</p>
			</li>
			<li>
				<h3>2 minutes</h3>
				<p>比起没有看视频的网站访问者，看过视频的访问者会在网站上多停留2分钟。</p>
			</li>
		</ul>
	</div>
</div>

<!--       -->
<!--       -->
<!-- MOBILE COMMERCE APP -->
<!--       -->
<!--       -->

<!--
<div class="deck5 mcapp">
	<h2 class="deck5_title">MOBILE COMMERCE APP</h2>
	<div class="clearfix">
		<div class="mcapp_text">
			72CAST provides real-time chat features and advanced live video streaming service. With these features, anyone could broadcast live video and interact with the viewers. You may also run the effective digital marketing campaign with our simulcast technology uploading the video contents automatically to SNS.
		</div>
		<div class="deck3_1_img"><img src="assets/img/commerce_app1.png" alt="" /></div>
	</div>
</div>
<div class="deck5 mcapp2">
	<div class="deck3_1_img"><img src="assets/img/commerce_app2.png" alt="" /></div>
	<div  class="mcapp_text">
		<div>Our global logistic network promises easy and simple delivery system and big data based sophisticated recommend algorithm grants unparalleled personalized customer service. On the other hand the sellers will experience our advanced ecommerce back-end engine to manage the entire online process with one screen.</div>
	</div>
</div>
-->

<!--       -->
<!--       -->
<!-- THE 3 MAJOR FACTORS V-COMMERCE -->
<!--       -->
<!--       -->

<div class="deck4 bluebg">
<h2 class="deck4_title">视频电子商务的3大主要因素</h2>
	<div class="deck4_cont">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/cont4_01.png" alt="" width="120px" height="120px" />
			</div>
			<!--div class="deck4_cont01_2">
				Vendor's Broadcast
			</div-->
			<div class="deck4_cont01_3">
				视频直播服务
			</div>
			<!--div class="deck4_cont01_4">
				It is a new concept for e-commerce, which combines 
				marketplace and MCN.
				Our innovative mobile v-commerce platform allows vendors to broadcast their product 
				like the TV home shopping channel and to communicate with customers on real time basis.
			</div-->
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/cont4_02.png" alt="" width="120px" height="120px" />
			</div>
			<!--div class="deck4_cont01_2">
				Flexible&Expandable
			</div-->
			<div class="deck4_cont01_3">
				行动商务平台
			</div>
			<!--div class="deck4_cont01_4">
				Our platform provides 
				user-friendly UI and one-stop console management with 
				900 payment gateways, 300-language pack and 400 shipping method so that 
				each vendor easily controls 
				the entire business process 
				with just one click.
			</div-->
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/cont4_03.png" alt="" width="120px" height="120px" />
			</div>
			<!--div class="deck4_cont01_2">
				Recommend Algorithm
			</div-->
			<div class="deck4_cont01_3">
				个性化的大数据分析
			</div>
			<!--div class="deck4_cont01_4">
				We are specializing in Big Data analysis so our platform offers customers an unparalleled shopping experience with personalized display, 
				item recommendation and preferable brand suggestion. Our sophisticated recommend algorithm will find out customers' need before they find it.
			</div-->
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- SELF-BROADCASTING OF THE VENDOR -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title">“自广“机能 (销售者专用)</h2>
	<div class="deck5_subtitle">销售者进行直播的时候，只需要先点击红色的”LIVE”按钮，我们的app将自动的找到可连接的最佳服务器后，销售者就可以在3秒后开始现场直播。在现场直播进行的同时，销售者可以看得到有几个人正在观看直播以及实时的订单数。在直播结束时，视频将会被自动的上传到我们的平台上，而错过直播的用户或是想要重看直播的用户都可以再度观看。
	</div>
	
	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone05_1_1.png" alt="Vendor's Special Broadcasting Menu" />
<!-- 				<div class="player">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/vendor1_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">
				&lt;销售者专用的广播机能&gt;
			</div>				
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone05_2_1.png" alt="Live Broadcasting of Server Connect" class="hidden-xs" />
				<img src="assets/img/phone05_2_1_m.png" alt="Live Broadcasting of Server Connect" class="visible-xs" />
<!-- 				<div class="player" style="top:72px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/vendor2_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">
				&lt;现场直播服务器连接&gt;
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone05_3_1.png" alt="Vendor's Live Channel Looks" />
<!-- 				<div class="player">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/vendor3_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">
				&lt;现场直播频道&gt;
			</div>	
		</div>
	</div>
</div>
<div class="deck5_1">

	<h2 class="deck5_title">以观众的身份观看现场直播</h2>
	<div class="deck5_subtitle">用户在观看现场直播的同时也可以通过我们的实时聊天 (Live Chat) 功能来和销售者聊天或者询问关于产品的问题	
	</div>
	
	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">				
				<img src="assets/img/phone06_1_1.png" alt="Customer's Live Channel Looks" />
<!-- 				<div class="player" style="top:72px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/user1_720p.mov" type='video/mp4'>
					</video>
				</div> -->				
			</div>
			<div class="deck5_cont01_2">
				&lt;现场直播频道&gt;
			</div>				
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone06_2_1.png" alt="Live Broadcasting & interaction" />
<!-- 				<div class="player" style="top:71px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/user2_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">
				&lt;现场直播 &amp; 现场互动&gt;
			</div>		
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/phone06_3_1.png" alt="Customer's Product Detail" />
<!-- 				<div class="player" style="top:71px;">
					<video id="my-video" class="video-js" controls autoplay muted loop preload="auto" width="242" height="430" poster="assets/img/video_blank.png" data-setup="{'controls': true, 'autoplay': true, 'preload': 'auto'}">
						<source src="assets/movie/user3_720p.mov" type='video/mp4'>
					</video>
				</div> -->
			</div>
			<div class="deck5_cont01_2">
				&lt;产品详情&gt;
			</div>	
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- Simulcast -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title">同时联播功能</h2>
	<div class="deck5_subtitle nthem">
		如果直播之前销售者选择同时联播功能的话，我们的App自动寻找最优服务器然后把视频上传到其他社交网站（比如，Facebook, Youtube, or Insatagram 等。）
	</div>
	
	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/simulcast1.png" alt="Screenshot1" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/simulcast2.png" alt="Screenshot2" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/simulcast3.png" alt="Screenshot3" />
			</div>
		</div>
	</div>
	
</div>

<!--       -->
<!--       -->
<!-- ADMINISTRATOR CONSOLE -->
<!--       -->
<!--       -->

<div class="deck6 blackbg">
	<h2 class="deck6_title">后台管理</h2>
	<div class="deck6_subtitle">72CAST的后台引擎是一个被开发成适合全球运营的系统。由我们在各国所达成协议的900个支付网关，300个语言及400间配送分公司，我们的平台将会带给您的企业极大的灵活性和可扩展性，而我们也将提供给销售者从库存管理到最终阶段的产品配送的一站式服务。
	</div>
	<div class="deck6_cont">
		<img src="assets/img/img_exp02.png" alt="Admin Panel" />
	</div>
	<div class="deck4_cont">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/language.png" alt="language" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3 sizeup">
				<strong>300</strong> 个语言
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/payment.png" alt="payment" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3 sizeup">
				<strong>900</strong> 个支付网关
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/shipping.png" alt="shipping" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3 sizeup">
				<strong>400</strong> 间配送分公司
			</div>
		</div>
	</div>
	
</div>

<!--       -->
<!--       -->
<!-- 72 CAST SERVICE GRADE -->
<!--       -->
<!--       -->

<div class="deck7">
	<h2 class="deck5_title"><span class="logo_72">72</span> <span class="logo_cast">CAST</span> B2B SERVICE GRADE</h2>
	
	<div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title01 price_table_title">基本<br/><span>(小型企业)</span></div>
        <div><div class="price_table_price">-/-</div>
			<div class="price_table_term">List Month / Per month</div></div>
        <div class="price_table_text"> 白色标签服务 </div>
		<div class="price_table_text">-</div>
        <div class="price_table_text">B后台引擎</div>
        <div class="price_table_text">Standalone</div>
        <div class="price_table_text">有包含服务器费用</div>
		<div class="price_table_text">Basic API</div>
		<div class="price_table_text">社交平台基本连接</div>
        <div class="price_table_text">-</div>
        <div class="price_table_text">平台费用t</div>
        <div class="price_table_text">手续费 5%</div>
        <div class="price_table_text">B EC 2 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">价格／Maintenance (月份)</div>
    </div>
    <div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title02 price_table_title">一般<br/><span>(中型企业)</span></div>
        <div><div class="price_table_price">-/-</div>
			<div class="price_table_term">List Month / Per month</div></div>
		<div class="price_table_text"> 白色标签服务 </div>
        <div class="price_table_text"> - </div>
        <div class="price_table_text">S后台引擎</div>
        <div class="price_table_text">中型市场</div>
		<div class="price_table_text">有包含服务器费用</div>
		<div class="price_table_text">Basic API</div>
		<div class="price_table_text">社交平台基本连接</div>
		<div class="price_table_text">Push Alarm 5,000</div>
		<div class="price_table_text">平台费用</div>
        <div class="price_table_text">手续费 10%</div>
        <div class="price_table_text">S EC 2 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">价格／Maintenance (月份)</div>
    </div>
    <div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title03 price_table_title">特殊<br/><span>(企业)</span></div>
        <div><div class="price_table_price">-/-</div>
        	 <div class="price_table_term">List Month / Per month</div></div>
        <div class="price_table_text"> 白色标签服务 </div>
		<div class="price_table_text"> 视频电子商务 (72 秒) </div>
        <div class="price_table_text">P后台引擎</div>
        <div class="price_table_text">公开市场</div>
		<div class="price_table_text">无包涵服务器费用</div>
		<div class="price_table_text">Extention API</div>
		<div class="price_table_text">在其他社交平台上同时联播</div>
		<div class="price_table_text">Push Alarm 500,000</div>
		<div class="price_table_text">独立费用</div>
        <div class="price_table_text">手续费 15%</div>
        <div class="price_table_text">P EC 2 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">价格／Maintenance (月份)</div>
    </div>
    <div class="price_table" data-modal-id="#contact">
    	<div class="price_table_title04 price_table_title">专业<br/><span>(企业)</span></div>
        <div><div class="price_table_price">-/-</div>
        	 <div class="price_table_term">List Month / Per month</div></div>
<div class="price_table_text"> - </div>
	   <div class="price_table_text"> 视频电子商务 (无限) </div>
        <div class="price_table_text">专业后台引擎 + 定制</div>
        <div class="price_table_text">公开市场</div>
		<div class="price_table_text">无包涵服务器费用</div>
		<div class="price_table_text">Extention API + Existing Sys Integration</div>
		<div class="price_table_text">在其他社交平台上同时联播</div>
		<div class="price_table_text">Push Alarm 1,000,000</div>
		<div class="price_table_text">独立费用</div>
        <div class="price_table_text">-</div>
        <div class="price_table_text">P EC 3 Apps</div>
        <div class="price_table_text">Android / iOS</div>
        <div class="price_table_order">价格／Maintenance (月份)</div>
    </div>
	<!--div class="btn_free_wrap">
		<a href="javascript:void(0);">Free Trial</a>
	</div-->
	
	<div id="contact">
		<form name='sendmail' role='form' method='post' action=>
			<div class="sendmail clearfix">
				<ul class="clearfix">
					<li><input tyle="text" placeholder="First *" name="first_name"/></li>
					<li><input tyle="text" placeholder="Last *" name="last_name"/></li>
					<li><input tyle="text" placeholder="E-mail *" name="email"/></li>					
					<li><input tyle="text" placeholder="Company name *" name="company_name"/></li>
					<li><input tyle="text" placeholder="Phone *" name="telephone"/></li>
					<li><input tyle="text" placeholder="URL" name="url"/></li>
					<li class="double"><textarea col="50" row="10" placeholder="Comment" name="comments"></textarea></li>
				</ul>
				<!--<div id="RecaptchaField1"></div>-->
				<input type='submit' name='submit' value='SEND'/>
				<input type='button' class='close' value='CLOSE'/>
			</div>
		</form>
	</div>
	<script>$('.price_table').leanModal({top:0, closeButton: '.close'});</script>
</div>

<!--       -->
<!--       -->

<div class="deck9">
	<div class="deck5_title">MCN INFLUENCERS</div>
	<div class="deck5_subtitle">我们正在招募与作为视频电商的领军企业的72CAST一起致力于商务模式革新的充满热情的网络红人。 如果您对此感兴趣，请与我们联系！</div>
<div class="deck9_inside">

<div class="noplay">
          <div class="span3">
          	<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ1.png" width="180px" height="180px"></div>
          		<div class="mem_name">Cho Long Kwon</div>
          		
          	</div>
          </div>
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ2.png" width="180px" height="180px"></div>
          		<div class="mem_name">Hyun Young Yoon</div>
          		
          	</div>
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ3.png" width="180px" height="180px"></div>
          		<div class="mem_name">Somevely</div>
          		
          	</div>
          </div>         
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ4.png" width="180px" height="180px"></div>
          		<div class="mem_name">Su Il Kim</div>
          		
          	</div>
          </div>

          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ5.png" width="180px" height="180px"></div>
          		<div class="mem_name">So Hyun Lee</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ6.png" width="180px" height="180px"></div>
          		<div class="mem_name">Hee Kyung Jeon</div>
          		
          	</div>	
          </div>
           <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ7.png" width="180px" height="180px"></div>
          		<div class="mem_name">Milkiss</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ8.png" width="180px" height="180px"></div>
          		<div class="mem_name">Min Ji Bae</div>
          		
          	</div>	
          </div>

      </div>
      <a href="mailto:contact@72cast.com"><input type='button' name='JOIN' value='J O I N'/></a>
  </div>
<!--
<div class="autoplay">
          <div class="span3">
          	<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ1.png"></div>
          		<div class="mem_name">Daniel D.J UM</div>
          		
          	</div>
          </div>
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ2.png"></div>
          		<div class="mem_name">Josephina S.Y Lee</div>
          		
          	</div>
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ3.png"></div>
          		<div class="mem_name">Thomas H.W Kang</div>
          		
          	</div>
          </div>         
          <div class="span3">
         	    <div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ4.png"></div>
          		<div class="mem_name">Justin M.K Kim</div>
          		
          	</div>
          </div>
          
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ5.png"></div>
          		<div class="mem_name">Duke J.W Mok</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ6.png"></div>
          		<div class="mem_name">Chris M.D Yeo</div>
          		
          </div>
          </div>
           <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ7.png"></div>
          		<div class="mem_name">Duke J.W Mok</div>
          		
          	</div>	
          </div>
          <div class="span3">
         		<div class="mem_background">
          		<div class="mem_pic"><img src="assets/img/influ8.png"></div>
          		<div class="mem_name">Chris M.D Yeo</div>
          		
          	</div>	
          </div>
  </div>-->

<script type="text/javascript" src="assets/js/slick/slick.min.js"></script>

</div>  
  
</div>

<!--       -->
<!--       -->
<!-- 72 CAST of extension industry -->
<!--       -->
<!--       -->

<div class="deck3 bluebg">
	<h2 class="deck3_title">扩展行业</h2>
	
	<div class="deck4_cont">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/game.png" alt="" width="120px" height="120px"/>
			</div>
			<div class="deck4_cont01_3">
				网络游戏行业
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/art.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				艺术拍卖会
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/eTicketing.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				电子订票
			</div>
		</div>
	</div>
	<div class="deck4_cont second">
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/travel.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				旅游休闲
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/luxury_brand.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				奢侈品牌
			</div>
		</div>
		<div class="deck4_cont01">
			<div class="deck4_cont01_1">
				<img src="assets/img/fashion.png" alt="" width="120px" height="120px" />
			</div>
			<div class="deck4_cont01_3">
				时装和化妆品
			</div>
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- Portfolio of 72 CAST -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title">合作伙伴资源组合</h2>
	<ul class="portfolio clearfix">
		<li class="Line"><img src="assets/img/logo1.png" alt="Line" /></li>
		<li><img src="assets/img/logo2.png" alt="Deutsch Telekom" /></li>
		<li class="CheetahMobile"><img src="assets/img/logo3.png" alt="Cheetah Mobile" /></li>
		<li><img src="assets/img/logo4.png" alt="FarEasTone" /></li>
		<li class="SCSB"><img src="assets/img/logo5.png" alt="SCSB" /></li>
		<li><img src="assets/img/logo6.png" alt="Mediacorp" /></li>
		<li class="Benz"><img src="assets/img/logo7.png" alt="Benz" /></li>
		<li><img src="assets/img/logo8.png" alt="Amadeus" /></li>
		<li class="Mediacom"><img src="assets/img/logo9.png" alt="Mediacom" /></li>
		<li class="more hidden-sm hidden-xs"><img src="assets/img/logo_more.png" alt="More" /></li>
	</ul>
	
</div>

<!--       -->
<!--       -->
<!-- 525 CAST (O2O Model) -->
<!--       -->
<!--    
<div class="deck5">
	<h2 class="deck5_title">525 CAST</h2>
	<div class="o2o clearfix">
		<div class="deck3_1_img"><img src="assets/img/o2o_model.png" alt="" /></div>
		<div class="o2o_text">
			<h3>Features of 525 Cast (O2O Model)</h3>
			1) Service for easy communication with off-line shop clerk<br/><br/>
			2) Direct P2P video calling and chat (No Server)<br/><br/>
			3) Web RTC video call for up to 12 people at once<br/><br/>
			4) CRM with 1:1 video calls and O2O-based video call orders<br/><br/>
			5) An effective tool for VIP and special customer management<br/><br/>
			6) Can be synchronised with in-store POS systems and/or iPads
		</div>
	</div>
</div>

    -->
<!--       -->
<!-- GLOBAL LOGISTIC NETWORK -->
<!--       -->
<!--       -->

<div class="deck8">

	<!-- Global Logistic network... -->
	<div class="m_container" style="text-align:center; background-color:#3b3d40;">
		<div class="global">
			<div style="">				
				<h2 class="global_title">全球物流网络</h2>
				<br><br/>
				<div class="global_text">为了成为一个全球领先的电子商务平台，我们不只提供资讯及通讯科技 (ICT) 的服务，我们也提供物流服务。目前，我们已和一间基于香港的全球物流公司达成合作关系，而这间物流公司在17个国家总共有42间分公司。</div>
				<br>
				<div class="global_text">有了这个强大的物流网络，我们打算从我们的物流合作伙伴公司所拥有分公司的国家开始而逐渐地打进东南亚市场。这个策略将会帮助我们更加轻易地打进这些国家的周边市场。</div>
			</div>
		</div>
	</div>
	<div class="container logistic">        
		<ul class="clearfix">
			<li><img src="assets/img/logo_korchina.png" alt="KORCHINA" /></li>
			<li><img src="assets/img/logo_ocs.png" alt="OCS" /></li>
			<li><img src="assets/img/logo_yamato.png" alt="YAMATO" /></li>
			<li><img src="assets/img/logo_freeway.png" alt="FREE WAY" /></li>
		</ul>
	</div>

</div>

<!--       -->
<!--       -->
<!-- CONCEPT PRODUCT<br/>WITH &THEM -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title"><span class="logo_72">72</span> <span class="logo_cast">CAST</span> USING THE OUR<br> FIRST PROJECT:<!--span class="logo_nthem">&amp;THEM</span--><span class="logo_nthem2"><img src="assets/img/logo_blue.png" alt="&THEM" width="200px" /></span></h2>
	<div class="nthem_container">
	<div class="deck5_subtitle nthem">
		在&amp;THEM，我们的目的是通过有趣的视频，不管是现场或事先录好的视频，来介绍给从18 – 35岁的目标用户年轻及有特色的时尚品牌。从设计师品牌Louis Quatorze开始，我们打算把更多类似的设计师品牌带进来，来制造引人入胜的视频给我们的用户享受观看。
	</div>
	
	<div class="deck5_cont">
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/nthem01.png" alt="Screenshot1" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/nthem02.png" alt="Screenshot2" />
			</div>
		</div>
		<div class="deck5_cont01">
			<div class="deck5_cont01_1">
				<img src="assets/img/nthem03.png" alt="Screenshot3" />
			</div>
		</div>
	</div>
	
	<div class="market">
		<em>Enjoy the v-commerce shopping experience.</em>
		<div class="go_market">
			<a href="https://itunes.apple.com/app/id1095994523" target="_blank"><img src="assets/img/banner1.png" alt="Download on the App Store" /></a>
			<a href="https://play.google.com/store/apps/details?id=com.applr.nthem.shop" target="_blank"><img src="assets/img/banner2.png" alt="Get it on Google play" /></a>
		</div>
	</div>
	</div>
</div>

<!--        -->
<!--        -->
<!-- We will change worldwide e-commerce -->
<!--        -->
<!--        -->

<div class="deck10">
	<div class="m_container" style="text-align:center; background-image:url('assets/img/back_b_b.png'); background-position: center; " >
		<div class="bb_big_top">
			<div class="bb_big">
				<span class="bb_big_title">We</span><br>
				<span class="bb_big_title">will ch</span><span class="bb_big_title2">ange</span><br>
				<span class="bb_big_title">world</span><span class="bb_big_title2">wide</span><br>
				<span class="bb_big_title">e</span><span class="bb_big_title2">-commerce</span>
			</div>
		</div>
		<div class="bb_big_top2">
			<div class="bb_big2">
				<div class="bb_big_image"><img src="assets/img/we_sl.png" alt="" /></div>
			</div>
		</div>
	</div>
</div>

<!--       -->
<!--       -->
<!-- Start free trial of 72 CAST -->
<!--       -->
<!--       -->

<div class="deck5">
	<h2 class="deck5_title">CONTACT US<!-- OF<br/><span class="logo_72">72</span> <span class="logo_cast">CAST</span--></h2>
	<div class="contact_subtitle">
		为了贵公司在使用了我们的APP之后，我们能为贵公司提供最适合的商业模式及后继的联系沟通，请留下对接人的邮箱和电话等联系方式。
	</div>
	<form name='sendmail' role='form' method='post' action=>
		<div class="sendmail clearfix">
			<ul class="clearfix">
				<li><input tyle="text" placeholder="First *" name="first_name"/></li>				
				<li><input tyle="text" placeholder="Last *" name="last_name"/></li>
				<li><input tyle="text" placeholder="E-mail *" name="e-mail"/></li>
				<li><input tyle="text" placeholder="Company name *" name="company_name"/></li>
				<li><input tyle="text" placeholder="Phone *" name="telephone"/></li>
				<li><input tyle="text" placeholder="URL" name="url"/></li>
				<li class="double"><textarea col="50" row="10" placeholder="Comment" name="comments"></textarea></li>
			</ul>
			<!--<div id="RecaptchaField2"></div>-->
			<input type='submit' name='submit' value='S E N D'/>
		</div>
	</form>
</div>

<!--        -->
<!--        -->
<!-- Address -->
<!--        -->
<!--        -->

<div class="deck3">
	<div class="m_deck_rest" >
		<div class="mbottom_logo">
			<!--img src="assets/img/bottom_logo_72cast.png"-->
			<img src="assets/img/72cast_logo.png" alt="72 CAST" />
		</div>
		<div class="mbottom_text03">
			<a href="mailto:contact@nthemshop.com.sg" style="color: white">contact@72cast.com</a>
		</div>
		<div class="mbottom_text04">
			Singapore Office : 71 Ayer Rajah Crescent #05-05 Singapore 139951.<br/>
			Korea Office : 33 Gonghang-dearo 59da-gil, Gangseo-gu, Seoul, Korea 07553.<br/>
		</div>


		<!--<div class="mbottom_icon2">
			<img src="assets/img/sns1.png" alt="facebook" />
			<img src="assets/img/sns2.png" alt="twitter" />
			<img src="assets/img/sns3.png" alt="instagram" />
		</div>-->
	</div>
</div>

<script>

$(".price_table").hover(function(e){
	$(this).children("div:first").addClass('price_table_title_over');
	$(this).children("div:last").addClass('price_table_title_over');
},function(e){
	$(this).children("div:first").removeClass('price_table_title_over');
	$(this).children("div:last").removeClass('price_table_title_over');
});

</script>

<!-- google analytics -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-79445648-1', 'auto');
  ga('send', 'pageview');

</script>

<script type="text/javascript">
  var onloadCallback = function() {    
    grecaptcha.render('RecaptchaField1', 
    	{
    		'sitekey' : '6LezNScTAAAAAOVNd0nmClPkryScSuCD9V3AC4Yu'
    	});
    grecaptcha.render('RecaptchaField2', 
    	{
    		'sitekey' : '6LezNScTAAAAAOVNd0nmClPkryScSuCD9V3AC4Yu'
    		// 'theme' : 'dark'
    	});
  };
</script>